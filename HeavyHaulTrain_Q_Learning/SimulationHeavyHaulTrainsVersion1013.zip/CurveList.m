clc;
clear all
CurvePositionList = [12000 13000 10000
                     13500 14000 10000];
save('CurvePositionList','CurvePositionList');