function ActionSet = get_ActionSet3()

ActionSet = zeros(3,1);

count = 0;
count = count+1; ActionSet(count, :) = 0; 
count = count+1; ActionSet(count, :) = -1; 
count = count+1; ActionSet(count, :) = 1; 

